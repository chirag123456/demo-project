@extends('layout')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">

  <a href="{{ route('share.index')}}" class="btn btn-primary">Back</a>
  </br>
  <br/>
  <table class="table table-striped">
    <tr>
      <th>ID:</th>
      <td>{{$share->id}}</td>
    </tr>
    <tr>
      <th>Stock Name:</th>
      <td>{{$share->share_name}}</td>
    </tr>
    <tr>
      <th>Stock Price:</th>
      <td>{{$share->share_price}}</td>
    </tr>
    <tr>
      <th>Stock Quantity:</th>
      <td>{{$share->share_qty}}</td>
    </tr>
  </table>
<div>
@endsection
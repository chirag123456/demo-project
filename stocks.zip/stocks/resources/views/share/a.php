@extends('layout')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  @if(session()->get('success'))
    <div class="alert alert-success">
      {{ session()->get('success') }}  
    </div><br />
  @endif
  <a href="{{ route('share.create')}}" class="btn btn-primary">Add</a>
</br>
<br />
  <table class="table table-striped">
    <thead>
        <tr>
          <td>@sortablelink('id','ID')</td>
          <td>@sortablelink('share_name','Share Name')</td>
          <td>@sortablelink('share_price','Share Price')</td>
          <td>@sortablelink('share_qty','Share Quantity')</td>
          <td colspan="3">Action</td>
        </tr>
    </thead>
<!--     <tbody>
        @foreach($shares as $share)
        <tr>
            <td>{{$share->id}}</td>
            <td>{{$share->share_name}}</td>
            <td>{{$share->share_price}}</td>
            <td>{{$share->share_qty}}</td>
            <td><a href="{{ route('share.edit',$share->id)}}" class="btn btn-primary">Edit</a>
                <a href="{{ route('share.show',$share->id)}}" class="btn btn-info" style="color: #fff;">View</a>
                <form action="{{ route('share.destroy', $share->id)}}" method="post">
                  @csrf
                  @method('DELETE')
                  <button class="btn btn-danger" type="submit">Delete</button>
                </form>
            </td>
            
        </tr>
        @endforeach
    </tbody> -->
  </table>
  
 <!--  {!! $shares->appends(\Request::except('page'))->render() !!} -->

<div>

@endsection
@push('scripts')
<script>
$(function() {
    $('.table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '{!! route('share.data') !!}',
        columns: [
            { data: 'id', name: 'id' },
            { data: 'share_name', name: 'Share Name' },
            { data: 'share_price', name: 'Share Price' },
            { data: 'share_qty', name: 'Share Qty' }
        ]
    });
});
</script>
@endpush

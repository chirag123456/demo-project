<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::resource('share', 'ShareController'); 
Route::get('anyData',['as'=> 'share.data','uses'=>'ShareController@anyData']);
Route::get('share/show/{id}',['as'=> 'share.show','uses'=>'ShareController@show']);
Route::get('share/delete/{id}',['as'=> 'share.delete','uses'=>'ShareController@destroy']);
Route::get('share/status/{id}',['as'=> 'share.status','uses'=>'ShareController@status']);
//Route::get('/getIndex','ShareController@index');


// Route::get('share', 'ShareController', [
//     'anyData'  => 'share.data',
//     'getIndex' => 'share',
// ]);

	 // Route::post('shares',['as'=> 'share.index','uses'=>'ShareController@index']);
	 // Route::post('share/create',['as'=> 'share.create','uses'=>'ShareController@create']);
	 // Route::post('share/store',['as'=> 'share.store','uses'=>'ShareController@store']);
	 // Route::post('share/store',['as'=> 'share.data','uses'=>'ShareController@store']);


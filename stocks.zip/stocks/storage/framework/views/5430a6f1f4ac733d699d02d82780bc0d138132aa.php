<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="uper">
  <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
      <?php echo e(session()->get('success')); ?>  
    </div><br />
  <?php endif; ?>
  <a href="<?php echo e(route('share.create')); ?>" class="btn btn-primary">Add</a>
</br>
<br />
  <table class="table table-striped">
    <thead>
        <tr>
          <th>ID</th>
          <th>Share Name</th>
          <th>Share Price</th>
          <th>Share Quantity</th>
          <th>Action</th>
        </tr>
    </thead>

  </table>
  

<div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('.table').DataTable({
        responsive: true,
        processing: true,
        serverSide: true,
        ajax: '<?php echo route('share.data'); ?>',
        columns: [
            
            { data: 'id', name: 'id' },
            { data: 'share_name', name: 'share_name' },
            { data: 'share_price', name: 'share_price' },
            { data: 'share_qty', name: 'share_qty' },
            {data: 'action', name: 'action', orderable: false, searchable: false}
        ],
            //order: [[1, 'asc']]

    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
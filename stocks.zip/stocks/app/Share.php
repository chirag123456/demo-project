<?php

namespace App;

//use Laravel\Scout\Searchable;
use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;


class Share extends Model
{
		//use Searchable;
		use Sortable;
    //
    protected $fillable = [
    'share_name',
    'share_price',
    'share_qty'
  ];

  public $sortable = ['id', 'share_name', 'share_price', 'share_qty'];

  /**
     * Get the index name for the model.
     *
     * @return string
     */
    /*public function searchableAs()
    {
        return 'index';
    }*/

    /**
     * Get the indexable data array for the model.
     *
     * @return array
     */
    /*public function toSearchableArray()
    {
        $array = $this->toArray();

        // Customize array...

        return $array;
    }*/

    /*public function getScoutKey()
    {
        return $this->email;
    }*/
}

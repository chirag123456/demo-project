<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
// use Illuminate\Pagination\Paginator;
// use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\DB;

use App\Share;

// use Datatables;
use Yajra\Datatables\Datatables;


class ShareController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        // $shares = Share::sortable()->paginate(3);
        //$shares = DB::table('shares')->paginate(1);
        //searchable()->
        // return Datatables::of(Share::query())->make(true);
        return view('share.index');

        // return view('share.index', compact('shares'));
    }

    public function anyData()
    {
        //$members =  Datatables::of(Share::query())->make(true);
        $members = DB::table('shares')
            ->select(['id','share_name','share_price','share_qty','is_active'])->where(['is_delete' => 'N']);
            
        return Datatables::of($members)
            ->addColumn('action', function ($members) {
                if(isset($members->is_active) && $members->is_active == "Y")
                {
                    $btn = '<a href="share/status/' . $members->id . '" class="btn btn-danger">In Active</a>';
                }
                else
                {
                    $btn = '<a href="share/status/' . $members->id . '" class="btn btn-info">Active</a>';
                }
                return '<a href="share/' . $members->id . '/edit" class="btn btn-primary">Edit</a>
                        <a href="share/show/' . $members->id . '" class="btn btn-success">View</a>
                        <a href="share/delete/' . $members->id . '" class="btn btn-default">Delete</a>
                        '.$btn.'
                        
                  '; })->make(true);
                  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
        return view('share.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $request->validate([
        'share_name'=>'required',
        'share_price'=> 'required|integer',
        'share_qty' => 'required|integer'
      ]);
      $share = new Share([
        'share_name' => $request->get('share_name'),
        'share_price'=> $request->get('share_price'),
        'share_qty'=> $request->get('share_qty')
      ]);
      $share->save();
      return redirect('/share')->with('success', 'Stock has been added');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
        $share = Share::find($id);

        return view('share.show', compact('share'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
         $share = Share::find($id);

        return view('share.edit', compact('share'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $request->validate([
        'share_name'=>'required',
        'share_price'=> 'required|integer',
        'share_qty' => 'required|integer'
      ]);

      $share = Share::find($id);
      $share->share_name = $request->get('share_name');
      $share->share_price = $request->get('share_price');
      $share->share_qty = $request->get('share_qty');
      $share->save();

      return redirect('/share')->with('success', 'Stock has been updated');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
     //$share = Share::find($id);
     //$share->delete();
      $share = Share::find($id);
      $share->is_delete = 'Y';
      $share->save();

      return redirect('/share')->with('success', 'Stock has been deleted Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function status($id)
    {
        //
     //$share = Share::find($id);
     //$share->delete();
      $share = Share::find($id);
      if($share->is_active == 'Y')
      {
        $share->is_active = 'N';
        $msg = 'success';
        $msg1 = 'Stock has been Deactivated Successfully';
      }
      else
      {
        $share->is_active = 'Y';
        $msg = 'success';
        $msg1 = 'Stock has been Activated Successfully';
      }

      $share->save();
      return redirect('/share')->with($msg , $msg1);
    }
}
